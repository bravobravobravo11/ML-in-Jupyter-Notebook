```python
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import Lasso
from sklearn import metrics
```


```python
car_dataset=pd.read_csv('car data.csv')
```


```python
car_dataset.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Car_Name</th>
      <th>Year</th>
      <th>Selling_Price</th>
      <th>Present_Price</th>
      <th>Kms_Driven</th>
      <th>Fuel_Type</th>
      <th>Seller_Type</th>
      <th>Transmission</th>
      <th>Owner</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>ritz</td>
      <td>2014</td>
      <td>3.35</td>
      <td>5.59</td>
      <td>27000</td>
      <td>Petrol</td>
      <td>Dealer</td>
      <td>Manual</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>sx4</td>
      <td>2013</td>
      <td>4.75</td>
      <td>9.54</td>
      <td>43000</td>
      <td>Diesel</td>
      <td>Dealer</td>
      <td>Manual</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>ciaz</td>
      <td>2017</td>
      <td>7.25</td>
      <td>9.85</td>
      <td>6900</td>
      <td>Petrol</td>
      <td>Dealer</td>
      <td>Manual</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>wagon r</td>
      <td>2011</td>
      <td>2.85</td>
      <td>4.15</td>
      <td>5200</td>
      <td>Petrol</td>
      <td>Dealer</td>
      <td>Manual</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>swift</td>
      <td>2014</td>
      <td>4.60</td>
      <td>6.87</td>
      <td>42450</td>
      <td>Diesel</td>
      <td>Dealer</td>
      <td>Manual</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
car_dataset.shape
```




    (301, 9)




```python
car_dataset.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 301 entries, 0 to 300
    Data columns (total 9 columns):
     #   Column         Non-Null Count  Dtype  
    ---  ------         --------------  -----  
     0   Car_Name       301 non-null    object 
     1   Year           301 non-null    int64  
     2   Selling_Price  301 non-null    float64
     3   Present_Price  301 non-null    float64
     4   Kms_Driven     301 non-null    int64  
     5   Fuel_Type      301 non-null    object 
     6   Seller_Type    301 non-null    object 
     7   Transmission   301 non-null    object 
     8   Owner          301 non-null    int64  
    dtypes: float64(2), int64(3), object(4)
    memory usage: 21.3+ KB
    


```python
car_dataset.isnull().sum()
```




    Car_Name         0
    Year             0
    Selling_Price    0
    Present_Price    0
    Kms_Driven       0
    Fuel_Type        0
    Seller_Type      0
    Transmission     0
    Owner            0
    dtype: int64




```python
car_dataset.replace({'Fuel_Type':{'Petrol':0, 'Diesel':1, 'CNG':2}}, inplace=True)
car_dataset.replace({'Seller_Type':{'Dealer':0, 'Individual':1}}, inplace=True)
car_dataset.replace({'Transmission':{'Manual':0, 'Automatic':1}}, inplace=True)
```


```python
car_dataset.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Car_Name</th>
      <th>Year</th>
      <th>Selling_Price</th>
      <th>Present_Price</th>
      <th>Kms_Driven</th>
      <th>Fuel_Type</th>
      <th>Seller_Type</th>
      <th>Transmission</th>
      <th>Owner</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>ritz</td>
      <td>2014</td>
      <td>3.35</td>
      <td>5.59</td>
      <td>27000</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>sx4</td>
      <td>2013</td>
      <td>4.75</td>
      <td>9.54</td>
      <td>43000</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>ciaz</td>
      <td>2017</td>
      <td>7.25</td>
      <td>9.85</td>
      <td>6900</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>wagon r</td>
      <td>2011</td>
      <td>2.85</td>
      <td>4.15</td>
      <td>5200</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>swift</td>
      <td>2014</td>
      <td>4.60</td>
      <td>6.87</td>
      <td>42450</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
X=car_dataset.drop(['Car_Name', 'Selling_Price'], axis=1)
Y=car_dataset['Selling_Price']
```


```python
print(X)
```

         Year  Present_Price  Kms_Driven  Fuel_Type  Seller_Type  Transmission  \
    0    2014           5.59       27000          0            0             0   
    1    2013           9.54       43000          1            0             0   
    2    2017           9.85        6900          0            0             0   
    3    2011           4.15        5200          0            0             0   
    4    2014           6.87       42450          1            0             0   
    ..    ...            ...         ...        ...          ...           ...   
    296  2016          11.60       33988          1            0             0   
    297  2015           5.90       60000          0            0             0   
    298  2009          11.00       87934          0            0             0   
    299  2017          12.50        9000          1            0             0   
    300  2016           5.90        5464          0            0             0   
    
         Owner  
    0        0  
    1        0  
    2        0  
    3        0  
    4        0  
    ..     ...  
    296      0  
    297      0  
    298      0  
    299      0  
    300      0  
    
    [301 rows x 7 columns]
    


```python
print(Y)
```

    0       3.35
    1       4.75
    2       7.25
    3       2.85
    4       4.60
           ...  
    296     9.50
    297     4.00
    298     3.35
    299    11.50
    300     5.30
    Name: Selling_Price, Length: 301, dtype: float64
    


```python
X_train, X_test, Y_train, Y_test=train_test_split(X, Y, test_size=0.1, random_state=2)
```


```python
lin_reg_model=LinearRegression()
```


```python
lin_reg_model.fit(X_train, Y_train)
```




    LinearRegression()




```python
training_data_prediction=lin_reg_model.predict(X_train)
```


```python
error_score=metrics.r2_score(Y_train, training_data_prediction)
print('R squared Error : ', error_score)
```

    R squared Error :  0.8670919068645732
    


```python
plt.scatter(Y_train, training_data_prediction)
plt.xlabel('Actual Price')
plt.ylabel('Predicted Price')
plt.title('Actual Prices vs Predicted Prices')
plt.show()
```


    
![png](output_16_0.png)
    



```python
test_data_prediction=lin_reg_model.predict(X_test)
```


```python
error_score=metrics.r2_score(Y_test, test_data_prediction)
print('R squared Error : ', error_score)
```

    R squared Error :  0.9197483209590676
    


```python
plt.scatter(Y_test, test_data_prediction)
plt.xlabel('Actual Price')
plt.ylabel('Predicted Price')
plt.title('Actual Prices vs Predicted Prices')
plt.show()
```


    
![png](output_19_0.png)
    



```python
lass_reg_model=Lasso()
```


```python
lass_reg_model.fit(X_train, Y_train)
```




    Lasso()




```python
training_data_prediction=lass_reg_model.predict(X_train)
```


```python
error_score=metrics.r2_score(Y_train, training_data_prediction)
print('R squared Error : ', error_score)
```

    R squared Error :  0.8333087808352386
    


```python
plt.scatter(Y_train, training_data_prediction)
plt.xlabel('Actual Price')
plt.ylabel('Predicted Price')
plt.title('Actual Prices vs Predicted Prices')
plt.show()
```


    
![png](output_24_0.png)
    



```python
test_data_prediction=lass_reg_model.predict(X_test)
```


```python
error_score=metrics.r2_score(Y_test, test_data_prediction)
print('R squared Error : ', error_score)
```

    R squared Error :  0.8820507285967961
    


```python
plt.scatter(Y_test, test_data_prediction)
plt.xlabel('Actual Price')
plt.ylabel('Predicted Price')
plt.title('Actual Prices vs Predicted Prices')
plt.show()
```


    
![png](output_27_0.png)
    



```python

```
